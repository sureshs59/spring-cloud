package com.Java.Graphql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphqlImplementationWithExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphqlImplementationWithExampleApplication.class, args);
	}

}
